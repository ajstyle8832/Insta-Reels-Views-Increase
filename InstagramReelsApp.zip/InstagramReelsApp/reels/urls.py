from django.urls import path
from . import views

urlpatterns = [
    path('increase-views/', views.increase_reels_views, name='increase_reels_views'),
]

