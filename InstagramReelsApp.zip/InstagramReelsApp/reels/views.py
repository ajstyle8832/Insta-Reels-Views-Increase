import requests
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, HttpResponse
from django.conf import settings

# Replace these values with your actual Instagram API credentials
INSTAGRAM_CLIENT_ID = '1248213715843678'
INSTAGRAM_CLIENT_SECRET = '235c2abc2998db2d62953c356ba6a9f4'
INSTAGRAM_REDIRECT_URI = 'http://localhost:8000/instagram_oauth/callback/'

@csrf_exempt
def increase_reels_views(request):
    if request.method == 'POST':
        try:
            reels_link = request.POST['reels_link']
            
            # Get access token using OAuth
            access_token = get_access_token(request.GET.get('code'))
            
            # Make a request to Instagram API to increment views
            response = requests.post(f'https://graph.instagram.com/{reels_link}/insights',
                                     params={'metric': 'impressions'},
                                     headers={'Authorization': f'Bearer {access_token}'})
            
            if response.status_code == 200:
                message = 'Reels views increased successfully.'
            else:
                message = 'Failed to increase Reels views.'
            
            return render(request, 'increase_views.html', {'message': message, 'reels_link': reels_link})
            
        except KeyError:
            return JsonResponse({'message': 'Invalid request parameters.'}, status=400)
        
    elif request.method == 'GET':
        return render(request, 'increase_views.html')

    return HttpResponse('Method not allowed.', status=405)

def get_access_token(code):
    # Exchange the authorization code for an access token
    response = requests.post('https://api.instagram.com/oauth/access_token', data={
        'client_id': INSTAGRAM_CLIENT_ID,
        'client_secret': INSTAGRAM_CLIENT_SECRET,
        'grant_type': 'authorization_code',
        'redirect_uri': INSTAGRAM_REDIRECT_URI,
        'code': code
    })
    
    if response.status_code == 200:
        return response.json().get('access_token')
    else:
        return None

def instagram_oauth(request):
    # Redirect user to Instagram authorization URL
    redirect_url = f'https://api.instagram.com/oauth/authorize?client_id={INSTAGRAM_CLIENT_ID}&redirect_uri={INSTAGRAM_REDIRECT_URI}&response_type=code'
    return redirect(redirect_url)

